from datetime import datetime
from distutils.command.upload import upload
from email.mime import image
from statistics import mode
from django.db import models
import datetime

# Create your models here.


    
class blogpost(models.Model):
    title = models.CharField(max_length=250)
    slug = models.SlugField()
    intro = models.TextField()
    content = models.TextField()
    author = models.CharField(max_length=200)
    imag = models.ImageField(null=True, blank=True, upload_to="images/")
    imag_alt = models.CharField( max_length=200)
    
    
    
class Message(models.Model):
    Headline = models.CharField(max_length=250)
    subtitle = models.CharField(max_length=250)
    link = models.URLField()    
       
    
    
    
    