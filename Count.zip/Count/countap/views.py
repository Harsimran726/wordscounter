from cgitb import html
from itertools import count
from django.shortcuts import render

# Create your views here.

def index(request):
   return render(request,'index.html')

#take text from front end
def counter(request):
    
    text = request.GET['Texttocount']
    length_of_space = len(text)
    length_of_text = len(text.replace(" ",""))
    ammount = text.split()
    total_words = len(ammount)
    total_sentences = len(text.split('.'))
    
    
    return render(request, 'index.html', {'length_of_text': length_of_text, 'text': text , 'total_words' : total_words , 'length_of_space': length_of_space ,
                                          'total_sentences' : total_sentences})