from cgitb import html
from http.client import HTTPResponse 
from itertools import count
from multiprocessing import context
from django.shortcuts import render , HttpResponse 
from datetime import date, datetime
from countap.models import blogpost
# Create your views here.

def index(request):
       return render(request,'Home/index.html')

def Contact(request):
       return render(request, 'Home/Contact.html')
    
def BlogHome(request):
       
       allposts = blogpost.objects.all()
       
       context = {'allposts': allposts}
       
       return render(request,'Blog/BlogHome.html', context)
 
def BlogPost(request, slug):
       postonly = blogpost.objects.filter(slug=slug).first()
       context = {'postonly': postonly}
       return render(request,'Blog/Post.html', context)
       
 


#take text from front end
def counter(request):
    
    text = request.GET['Texttocount']
    length_of_space = len(text)
    length_of_text = len(text.replace(" ",""))
    ammount = text.split()
    total_words = len(ammount)
    total_sentences = len(text.split("."))
    
    
    return render(request, 'Home/index.html', {'length_of_text': length_of_text, 'text': text , 'total_words' : total_words , 'length_of_space': length_of_space ,
                                          'total_sentences' : total_sentences})