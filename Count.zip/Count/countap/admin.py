from django.contrib import admin
from countap.models import blogpost , Message

# Register your models here.
admin.site.register(blogpost)
admin.site.register(Message)

